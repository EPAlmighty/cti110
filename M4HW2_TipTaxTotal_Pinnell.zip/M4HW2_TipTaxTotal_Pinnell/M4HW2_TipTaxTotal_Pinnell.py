#CTI 110
#M4HW2- Tip Tax Total
#Evan Pinnell
#11/19/17


foodCost = float(input( "Amount of your meal:"))

salesTax = .07

tip = .18

totalCost = foodCost * salesTax *tip

print( 'Total:', totalCost)

