#CTI 110
#M6T1a
#Evan Pinnell
#11/27/17


import turtle
def main():
    
    win = turtle.Screen()
    evan = turtle.Turtle()

    evan.pensize(4)
    evan.pencolor('green')
    
#Sqaure
    for sides in range(4):
        evan.forward(50)
        evan.right(90)                 
    evan.penup()
    evan.forward(100)
    evan.pendown()
#Triangle
    for sides in range(3):
        evan.forward(50)
        evan.left(120)

main()

