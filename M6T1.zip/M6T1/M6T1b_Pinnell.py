#CTI 110
#M6T1- Intitials
#Evan Pinnell
#11/29/17

import turtle

def main():

    win = turtle.Screen()
    evan = turtle.Turtle()

    evan.pensize(4)
    evan.pencolor('blue')
    evan.shape('turtle')

    evan.forward(50)
    evan.left(180)
    evan.forward(50)
    evan.left(90)
    evan.forward(50)
    evan.left(90)
    evan.forward(50)
    evan.left(180)
    evan.forward(50)
    evan.left(90)
    evan.forward(50)
    evan.left(90)
    evan.forward(50)

    evan.penup()
    evan.forward(50)
    evan.pendown()

    evan.left(90)
    evan.forward(100)
    evan.right(90)
    evan.forward(50)
    evan.right(90)
    evan.forward(50)
    evan.right(90)
    evan.forward(50)
    
main()    

    
